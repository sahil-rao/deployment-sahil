import cx_Oracle
from pprint import pprint

oracle_vm_ip = '10.239.109.141'
connection_string = 'tpch/tpch@' + oracle_vm_ip + '/orcl'
#query_str = "select * from nation"
query_str = "select sql_id, elapsed_time, sql_profile, module, parsing_user_id, parsing_schema_id, sql_text, sql_fulltext from v$sql where parsing_schema_name=upper('tpch') and module='TPCH_APP'"
column_map = {  'sql_id': 0
               ,'elapsed_time': 1
               ,'sql_profile': 2
               ,'module': 3
               ,'parsing_user_id': 4
               ,'parsing_schema_id': 5
               ,'sql_text': 6
               ,'sql_fulltext': 7 }
               
con = cx_Oracle.connect(connection_string)
cur = con.cursor()
cur.execute(query_str)
res = cur.fetchall()
cur.close()
con.close()

with open('testsql.sql', 'w') as f:
    for row in res:
        f.write(row[column_map['sql_text']] + ';')

# for row in res:
#     pprint(row[column_map['sql_text']])


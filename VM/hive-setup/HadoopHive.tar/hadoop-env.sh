export JAVA_HOME="/usr/lib/jvm/java-1.7.0-openjdk-amd64"
HADOOP_OPTS=-Djava.net.preferIPv4Stack=true

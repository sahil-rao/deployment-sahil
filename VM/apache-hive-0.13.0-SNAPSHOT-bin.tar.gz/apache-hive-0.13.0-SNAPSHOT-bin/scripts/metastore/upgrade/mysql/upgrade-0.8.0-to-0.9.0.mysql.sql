SELECT 'Upgrading MetaStore schema from 0.8.0 to 0.9.0' AS ' ';
SELECT 'Finished upgrading MetaStore schema from 0.8.0 to 0.9.0' AS ' ';
